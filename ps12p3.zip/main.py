#prompt user to enter line of comma-separated-values
line = input("Enter line of comma-separated-values: ")

#use string method split() to split the line into items
line_items = line.split(",")

#iterate through every item in list line_items
for item in line_items:
 #print item after removing any leading/trailing spaces from each item
 print(item.strip())