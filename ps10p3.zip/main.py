
def display(scoresArray):
    #for finding highest Value
    high_var = 0
    for i in range(len(scoresArray)):
        if scoresArray[i] > high_var:
            high_var = scoresArray[i]
            high_var = i
            
    #for finding lowest values
    low_var = 999
    for i in range(len(scoresArray)):
        if scoresArray[i] < low_var:
            low_var = scoresArray[i]
            low_var = i

            
    sum_var = 0
    for i in range(len(scoresArray)):
        sum_var = sum_var + scoresArray[i]

    Avg_var = low_var/len(scoresArray)

    print("your last name ")
    print("scores array =" , scoresArray)
    print("higest value =" , high_var)
    print("lowest value =" , low_var)
    print("average value =" , Avg_var)



scoresArray = [98, 13, 55, 89, 12, 88, 93, 57, 73]
display(scoresArray)

