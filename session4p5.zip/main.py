
lastname = input("enter employee last name ")
salary = float(input("enter the  salary "))
job = float(input("enter the job level "))

if job > 10 and job < 10:
  rate = 0.25
elif job >= 5 and job < 9:
  rate = 0.20
else:
  rate = 0.10
  
rate = salary * rate

print("employee last name is     " ,  lastname)
print("employee bonus rate is    " , rate)
