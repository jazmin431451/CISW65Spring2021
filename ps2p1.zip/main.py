#compute quantity * priceperunit 
quantity = float(input("Enter a floating point number"))
priceperunit = float(input("Enter the float"))

#process phase
extended = quantity * priceperunit

#output phrase
print("extended is " + str(extended))

