
startv = float(input("enter a start value"))
stopv = float(input("enter the stop value"))
incrv = float(input("enter increment value"))

incrv = 10

while startv <= stopv:
    
    print("loop - start value",  startv)
    startv = startv + incrv
