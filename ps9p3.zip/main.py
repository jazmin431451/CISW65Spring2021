def compute_sales(last_name, sales):
   if(sales > 100000):
       commision = (10 * sales)/100
   else:
       commision = (5 * sales)/ 100
       
   target = (5 * sales)/ 100
   return  last_name,commision,target

last_name = input("Enter last name: ")
sales = int(input("Enter the sales: "))
compute_sales(last_name,sales)
print("The lastname, commision and target sales:",)