#compute price of item and discount percent 
priceofitem = float(input("enter the price of item"))
discountpercent = float(input("Enter the discount percent"))

#process phrase
discount = priceofitem * discountpercent
discountpercent = priceofitem - discount

#output phrase 
print("discount is " + str(discount))
print("discount price is " + str(priceofitem - discount))
