# compute tax and total
amtofitem = float(input("Enter amount of the item"))

# process phase 

tax = amtofitem * 0.07
total = tax + amtofitem

#output phrase
print ("Amount entered: $", amtofitem)
print ("Tax is:         $", tax)
print("Total order:     $", total)

