
def compcost(gallons):
    cost = gallons * 2.50
    
    return cost

def compmiliespergallon(milies, gallons):
    miliespergallon = milies / gallons
    
    return miliespergallon

city = input("enter the destination city")
milies = float(input("enter the milies travelled"))
gallons = float(input("enter gallons"))
compmiliespergallon(milies, gallons)
miliespergallon = compmiliespergallon(milies, gallons)
compcost(gallons)
cost = compcost(gallons)
print("destination city is  ", city)
print("mpg is ", (milies))
print("cost of gallons is ", cost)
