f = open("data5.txt", "r")

#initialize countersand sums to 0
c = 0.0
totp_tuition =0.0

# get first data line
lastname = str(f.readline() .rstrip('\n'))

while lastname !="":
    discode = str(f.readline() .rstrip('\n'))
    credit = float(f.readline())
    if discode == "I":
        costcredit = 250.00
    else:
        costcredit = 500.00

    tuition = credit * costcredit
    #sum and count - in the loop
    totp_tuition = totp_tuition  + tuition 
    c = c+1

    #display a line of data
    print("lastname is:          ", lastname)
    print("credit is:      ", credit)
    print("cost is:         ", costcredit)
    print("tuition cost is ", tuition)

    # get next ata
    lastname = str(f.readline().rstrip('\n'))

# after the loop
#final calculations
#display them and sum amd counts
print("total tuition cost:  ", totp_tuition)
print("number of tuition:        ", c)
avg = totp_tuition / c
print("Average tuition:          ", avg)