#compute hours and rate
lastname = input("Enter your lastname")
hours = float(input("enter hours"))
rate = float(input("Enter pay rate"))

#process phase

grosspay = hours * rate

#output phrase
print(lastname + "," + str (grosspay))

