
def compavg(hits, bats):
    avg = hits / bats
    
    return avg

lastname = input("Enter the players lastname ")
hits = float(input("Enter the number of hits "))
bats = float(input("Enter the players bats "))
compavg(hits, bats)
avg = compavg(hits, bats)
print("player name is      ", lastname)
print("batting average is  ", avg)
