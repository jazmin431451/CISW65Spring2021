
def compgrosspay(hrs, payrate):
    grosspay = hrs * payrate
    
    return grosspay

def comppayrate(jobcode):
    if jobcode == "L":
        payrate = 25
    else:
        if jobcode == "A":
            payrate = 30
        else:
            if jobcode == "J":
                payrate = 50
    
    return payrate

lastname = input("enter the employee lastname ")
jobcode = input("enter the job code L, A or J ")
hrs = float(input("enter the hours worked "))
comppayrate(jobcode)
payrate = comppayrate(jobcode)
compgrosspay(hrs, payrate)
grosspay = compgrosspay(hrs, payrate)
overtime = 1.5 * hrs
print("employee lastname is    " , lastname)
print("employee gross pay is   " , grosspay)
