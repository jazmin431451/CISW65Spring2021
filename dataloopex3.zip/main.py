f = open("data3.txt", "r")

#initialize counters and accumulators to 0
total_bonus = 0
c = 0

#get first line of data
lastname = str(f.readline().rstrip('\n'))   #rstrip removes the return line feed (enter key) from the line

# loop while there is data to process
# lastname empty is end of file
while lastname != "":
  salary = str(f.readline().rstrip('\n'))   #rstrip removes the return line feed (enter key) from the line
  print("Employe Last Name: ", lastname)
  print("Employee Salary: $", format(float(salary), '10,.2f'))
  bonus = float(salary) * 0.10
  print("Employee Bonus: $", format(bonus,'10,.2f'))
  # sum the bonuses for every entry
  total_bonus = total_bonus + bonus
  # count the number of entries
  c = c + 1
  # get next line of data
  lastname = str(f.readline().rstrip('\n'))   #rstrip removes the return line feed (enter key) from the line

#close the file
f.close()

# compute the average based on sum of bonuses and count.
avg_bonus = total_bonus / c
print(" ")
print("Average Bonus: $", format(float(avg_bonus),'10,.2f'))