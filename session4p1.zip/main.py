
qty = float(input("enter the quantity of widgets "))
price = float(input("enter the price "))

if qty > 10000:
  price = 10
elif qty > 5000:
  price = 20
else:
  price = 30
  
extprice = qty * price

tax = extprice * 0.07

print("extened price is          ",   extprice)
print("tax amount and total is   ",   tax)
