def compute_total(item, price):
   global tax,total
   total = item * price
   tax = (7 * total)/100
   
item = int(input("Enter the items numbers: "))
price = float(input("Enter the unit price: "))
compute_total(item,price,total,tax)
print("Total prices and tax:",)