counter = 0
totalex1 = 0.0

response = input("want to calculate avrage score yes or no")

while response == "yes":
 counter = counter + 1
 lastname =input("enter student last name ")
 score1 = float(input("enter exam score 1 "))
 score2 = float(input("enter exam score 2 "))
 avg = (score1 + score2)/2
 print(lastname, " has average of " , avg)
 totalex1 = totalex1 + score1
 response = input("want to calculate average score yes or no")

avgex1 = totalex1 / counter
print("number of students: ",   counter)
print ("average exam score 1 ", avgex1)
