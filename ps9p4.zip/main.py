
def compute_scores(last_name, h1,h2,h3,score1,score2,score3):
   avg_scores = (score3 + score2 + score1) / 3
   if(h1 == h2):
       avg_scores_handicap = (score1 + score2)/ 2
       avg_scores_handicap = str(avg_scores_handicap) + " " + h1
   elif(h1 == h3):
       avg_scores_handicap = (score1 + score3)/ 2
       avg_scores_handicap = str(avg_scores_handicap) + " " + h3
   elif(h2 == h3):
       avg_scores_handicap = (score2 + score3)/ 2
       avg_scores_handicap = str(avg_scores_handicap) + " " + h2
   else:
       avg_scores_handicap = avg_scores
   
   return last_name,avg_scores, avg_scores_handicap

last_name = input("Enter last name: ")
h1 = input("Enter handicap1: ")
score1 = int(input("Enter the score1: "))
h2 = input("Enter handicap2: ")
score2 = int(input("Enter the score2: "))
h3 = input("Enter handicap3: ")
score3 = int(input("Enter the score3: "))
print("The lastname, avg_scores and avgScores_hamdicaped")
compute_scores(last_name,h1,h2,h3,score1,score2,score3)