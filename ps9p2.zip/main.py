def compute_score(last_name,score1,score2,score3):
    total_score = score1 + score2 + score3
    avg_scores = total_score / 3
    return last_name,total_score,int(avg_scores)

last_name = input("Enter student's last name: ")
score1 = int(input("Enter the Score1: "))
score2 = int(input("Enter the Score2: "))
score3 = int(input("Enter the Score3: "))
print("lastname,total_score,avg_scores:")
compute_score(last_name,score1,score2,score3)
