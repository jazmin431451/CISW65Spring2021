
partno = float(input("enter the part number"))
qty = float(input("enter quantity to purchase"))

if partno == 10 or partno == 55:
  up = 1.00
elif partno == 99:
  up = 2.0
elif partno == 80 or partno == 70:
  up = 3.00
else:
 up = 5.00

total = up * qty

print(partno)
print(qty)
print(up)
print(total)
