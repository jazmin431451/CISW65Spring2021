counter = 0
totalgrosspay = 0
response = input("do you want to compute you program ")

while response == "yes":
    counter = counter + 1
    lastname = input("employee last name ")
    hrs = int(input("how many hours you work "))
    ratepay = float(input("how much rate pay "))
    if hrs <= 40:
        grosspay = (hrs - 40) * ratepay * 1.5 + 40 * ratepay
        print(" your pay is $",  grosspay)
    else:
        grosspay = ratepay * hrs
        print("your gross pay over time: $", grosspay)
    totalgrosspay = totalgrosspay + grosspay
    print(lastname + " has pay of $", grosspay)
    response = input("do you want to compute you program ")
    
avggrosspay = totalgrosspay / counter

print("Sum of all Gross Pay is $", totalgrosspay)
print("Number of employees "     ,      counter)
print("Average Gross Pay is $"   ,    avggrosspay)
