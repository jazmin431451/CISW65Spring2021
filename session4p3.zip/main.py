
principle = int(input("Enter principle amount of CD "))
year = input("Enter the year maturity of CD ")

if principle > 100000 and year == 5:
  rate = 0.06
elif principle >= 50000 and year == 10:
  rate = 0.05
elif principle >= 50000 and year == 5:
  rate = 0.04
else:
  rate = 0.02

year = principle * rate

print("principle cd:        ", principle)
print("interest rate:       ", rate)
print("year to maturity:    ", year)
