
tickets = int(input("enter number of tickets "))

if tickets >= 25:
   price = 50
elif tickets >= 10 and tickets < 24:
  price = 60
elif tickets >= 5 and tickets < 9:
  price = 70
elif tickets > 5:
  price = 75
              
total = tickets * price

print("the number per tickets:     " , tickets)
print("the price per tickets:      " , price)
print("the total cost:             " , total)
