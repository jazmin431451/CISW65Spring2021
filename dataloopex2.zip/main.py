# first two terms of fibonacci series
count = int(input("Enter count of terms: "))
n1 = 0
n2 = 1 
i = 0  

#variable for loop
for i in range(1,count+1,1):  
#for loop upto nth term
      print(n1)
      sum = n1 + n2  
#Logic for the fibonacci series
      n1 = n2
      n2 = sum
      i = i + 1