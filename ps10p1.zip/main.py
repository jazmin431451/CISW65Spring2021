def displaynames(lastn):
    for i in lastn:
        print(i)
def displayr(lastn):
    l = len(lastn)
    print("Number of arrey elements " , 1)
    print("Arrays in order ")
    for y in range (0, 1, 1):
        print(lastn[y])
        print("Arrays in reverse order ")
    for y in range (1-1, 0, -1):
        print(lastn[y])

f = open ("lastn.txt" , "r")
c = 0
lastname = f.readline()
lastn = []

while lastname != "":
   c = c + 1
   lastn.append(str(lastname.rstrip("\n")))
   lastname = f.readline()
f.close()
displayr(lastn)
displaynames(lastn)
