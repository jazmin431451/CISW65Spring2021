def comptuitionowed(credithours, districtcode):
    if districtcode == "I":
        tuitionowed = credithours * 250
    else:
        if districtcode == "O":
            tuitionowed = credithours * 550
    
    return tuitionowed

totalcharge = 0
lastname = input("enter student lastname ")
districtcode = input("enter the district code I or O ")
credithours = float(input("enter credit hours"))
comptuitionowed(credithours, districtcode)
totalcharge = comptuitionowed(credithours, districtcode)
print("student last name is " + lastname)
print("Student Owes Tuition Charge is $" + str(totalcharge))
