#compute credit hours and lab fee
lastname = input("Enter your lastname")
creditstaken = float(input("Enter a creditstaken"))

#process phase
totaltuition = creditstaken * 250 + 100

#output phrase
print(lastname + "," + str(totaltuition))
