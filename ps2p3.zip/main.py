# compute length and width
length = float(input("Enter length of rectangle"))
width = float(input("Enter width of rectangle"))

#process phase

a = length * width 
c = 2 * length + 2 * width

#output phrase
print("area is" + str(a))
print("circrumference is" + str(c))