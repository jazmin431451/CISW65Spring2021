def Dl1 (thelist):
    n = int(input("Enter number of item for your list"))
    for n in range(0,n,1):
        s = int(input("enter an integer "))
        thelist.append(s)
    return thelist
def displaylist(thelist):
    for item in thelist:
        print(item)


thelist = []
thelist = Dl1(thelist)
print(thelist)

#Dl2
thelist.insert(0,99)
print(thelist)

#Dl3
thelist[0] = 100
print(thelist)

#Dl4
thelist2 = ['500', '600', '700', '800']
print(thelist2)
thelist.extend(thelist2)

#Dl5
thelist2.remove('800')
print(thelist2)

#Dl6
thelist2.remove('700')
print(thelist2)


#Dl768
listgrade = ['A', 'B', 'C', 'A', 'A', 'C']
print(listgrade.count('A'))

#Dl9
print(listgrade.index('B'))

#Dl10
#F = listgrade.index('F')
#if F in listgrade:
 # print("ok")
#else:
  #print("Not in list")

#Dl11
thelist2.clear()
print(thelist2)

#Dl13614
playerlist = ["Rizzo", "Devis", "Beez", "Happ", "Bryan"]
playerlist.sort()
print(playerlist)

#Dl15
playerlist2 = ["Rizzo", "Devis", "Beez", "Beez", "Happ", "Bryan"]
print(playerlist2)

#Dl16
playerlist2.reverse()
print(playerlist2)