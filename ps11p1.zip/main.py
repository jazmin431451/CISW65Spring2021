def Dl1 (mylist):
    n = int(input("number of item for your list"))
    for n in range(0,n,1):
        s = int(input("enter a number "))
        mylist.append(s)
    return mylist
def displaylist(mylist):
    for item in mylist:
        print(item)

#main
mylist = []
mylist = Dl1(mylist)
displaylist(mylist)
print(mylist)

#Dl2
score_list = [45, 67, 89, 90, 78]
score_list.insert(1, 99)
print(score_list)
#Dl3
list = [1, 2, 3, 4, 5]
list.insert(1, 99)
list[1] = 100
print(list)
#Dl4
list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] 
list1.insert(1,99) 
print(list1)
list1[1] = 100
print(list1)
list2 = [500, 600, 700, 800, 900]
print(list2)
list1.extend(list2)
print(list1)
#Dl5
list = [1, 2, 3, 4, 5]
list.insert(1, 99)
list.index[99] = 100
print(list)
list.remove(800)
print(list)
 #Dl6
l = [800, 99, 100]
l.insert(1, 99)
l[1] = 100
print(l)
l.remove(800)
print(l)
del l[2]
print(l)
#D18
grades = ["A", "B", "C", "A", "A", "C"]
count = 0
for grade in grades:

 if grades == "A":
  count = count + 1
print(count)
#Dl9
a_count = grades.count('A')
print("There are {} A grades".format(a_count))
b_index = grades.index('B')
print("The first B grade is at index {}".format(b_index))
#DL10
grades = ["A", "B", "C", "A", "A", "C"]
a_count = grades.count("A")

print("There are {} A grades"  .format(a_count))
b_index = grades.index("B")
print("The first B grade is at index {}.".format(b_index))
if "F" not in grades:
   print("There is no grade of F in the list.") 
#Dl11
grades = ["A", "B", "C", "A", "A", "C"]
print("The number of A grades is:", grades.count("A"))
print("The index of the first B grade is:", grades.index("B"))
if "F" in grades:
   print("F is in the list.")
else:
   print("F is not in the list.")
grades = []
print("The list is now clear.")
#Dl12
grades = ["A", "B", "C", "A", "A", "C"]
print(grades.count("A"))
print(grades.index("B"))

#Dl13
players_list = ["Rizzo", "Davis", "Baez", "Happ", "Bryant"]
#Dl14
List = ["Rizzo", "Davis", "Baez", "Happ", "Bryant"]
List.sort()
print(List)
#Dl15
players = ["Rizzo", "Davis", "Baez", "Happ", "Bryant"]
players.sort()
print(players)
#Dl16
players = ["Rizzo", "Davis", "Baez", "Happ", "Bryant"]
players.sort()
print(players)
players2 = players.copy()
print(players2)
players2.reverse()
print(players2)