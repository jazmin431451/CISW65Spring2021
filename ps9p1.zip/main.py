
def compute(qty,price,discount_rate):
   discount_amount = qty*((price * discount_rate)/100)
   discounted_price = price - discount_amount
   return discount_amount,discounted_price

qty = int(input("Enter the quantity:"))
price = float(input("Enter the price:"))
discount_rate = float(input("Enter the discount rate:"))
compute(qty,price,discount_rate)
print("Discount_amount,Discounted_price:")