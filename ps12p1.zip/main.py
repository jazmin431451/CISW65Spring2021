#function to get name from user
def getname():
    name  = input("Enter the name:")
    return name
#function to print name according to given format   
def display_name(name):
    #strip() method of string remove extra whitespaces before and after the string
    #split() method returns a list of strings after breaking the given string by the specified separator. 
    #default separator is whitespace ,multiple whitespaces are ignored by split function
    name_list = name.strip().split()
   
    if len(name_list) != 2:#if there are not exactly two values in the array input string is invalid
        print("Invalid input!")
    else:
        last_name = name_list[1]#name_list[1] gives lastname
        name_initial = name_list[0][0]#name_list[0][o] gives first letter of first name
        print(f"{last_name}, {name_initial}.")#print according to given format
        
def main():
    name = getname()
    display_name(name)
main()