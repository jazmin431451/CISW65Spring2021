
#dispalys all employess and there respective salaries
def displaynames(lastn, salary):
    for i in lastn, salary:
        print(i)
    for y in salary:
        print(y) 


#finds employee with the highest salary
def displayr(lastn, salary):
    l = len(lastn)
    print("Number of arrey elements " , 1)
    print("Arrays in order ")
    for y in range (0, 1, 1):
        print(lastn[y], salary[y])
        print("Arrays in reverse order ")
    for y in range (1-1, -1, -1):
        print(lastn[y], salary[y])

f = open ("lnames.txt" , "r")

total_bonus = 0 
c = 0
print("here")

lastname = f.readline()
lastn = []
salary = []
        
#takes name input checks is employee exist and display there salary
def findEmployeeSalary(employees, salarys):
    while True:
        employee_name = input("\nEnter employee name: ")
        if employee_name in employees:
            index = employees.index(employee_name)
            print("Employee Name: " + employee_name)
            print("Employee salary: $"+ str(salarys[index]))
        else:
            print("Employee not found. Please try again\n")
            continue
        break
        
#calls all the above functions one ata a time
while lastname != "":
    c = c + 1
    lastn.append(str(lastname).rstrip("\n"))
    s = float(f.readline())
    salary.append(s)
    lastname = f.readline()
    
f.close()
displaynames(lastn,salary)
displayr(lastn, salary)

