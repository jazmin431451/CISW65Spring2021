
def comptotal(qty, price):
    total = qty * price
    if total > 10000.00:
        total = total * 0.90
    else:
        total = total
    
    return total


qty = float(input("enter the quantity"))
price = float(input("enter the price"))
comptotal(qty, price)
total = comptotal(qty,price)
print("quantity is  ", qty)
print("price is     ", price)
print("total is     ", total)
