def displaylastnames(lastn,bavg):
    for i in lastn, bavg:
        print(i)
    for y in bavg:
        print(y)


def displayr(lastn,bavg):
    l = len(lastn)
    print("number of array elements " , 1)
    print("array in order ")
    for y in range(0, 1, 1):
        print([y], bavg[y])
        print("array in reverse order ")
    for y in range(1-1, -1, -1):
        print(lastn[y], bavg[y])
        
f = open ("bavg.txt" , "r")

total_avg = 0
c = 0
print("here"
     )
lastname = f.readline()
lastn = []
bavg = []
def findplayeraverage(player,bavg):
    while True:
        player_name = input("\nEnter player name: ")
        if player_name in player:
            index = player.index(player_name)
            print("player name: " + player_name)
            print("player average: $"+ str(bavg[index]))
        else:
            print("player not. please try again\n")
            continue
        break

while lastname != "":
    c = c + 1
    lastn.append(str(lastname).rstrip("/n"))
    s = float(f.readline())
    bavg.append(s)
    lastname = f.readline()
    
f.close()
displaylastnames(lastn, bavg)
displayr(lastn, bavg)