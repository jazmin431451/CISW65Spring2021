# creating function for repeating lines for number of character and shifting them right/left
def repeatShift(line):
        # taking input of number of characters to print in each line
        noOfChar = int(input("Enter no. of characters to print in each lines: "))
        # taking input of numbers of line to print 
        noOfLine = int(input("Enter no. of lines to print: "))
        # taking input of the scroll direction
        scrDirection = input("Enter scroll direction of Line: Right: r || Left: l -> ")

        # declaring shift and assigning different values of spaces according to scroll direction(i.e left or right)
        shift = ""
        if scrDirection == "r":
                shift = ""
        elif scrDirection == "l":
                shift = " " * (noOfLine - 1)

        # creating a counter variable initialised to 0, which will keep the count of characters displayed in each line(as in next line, the line will be printed from the next character of last character of previous line)
        counter = 0

        # nested for loop for printing the lines and number of characters from each line
        for i in range(noOfLine):
                # this outer loop is responsible for printing each line and shift spaces of either left or right scroll direction
                print(shift, end='')

                # after printing shift, shift is incremented/decremented according to right/left value of scroll direction
                if scrDirection == "r":
                        shift += " "
                elif scrDirection == "l":
                        shift = shift[:-1]

                # this inner loop in resposible for printing each line character by character upto number of characters in each line(which is entered by user)
                for j in range(noOfChar):
                        # printing each character
                        print(line[counter], end='')
                        # incrementing character by one and mod by len of text line(because if all characters of string of text is printed, then count variable will again be initialised to zero according to the formula)
                        counter = (counter + 1) % len(line)
                # changin line after each line has been printed
                print()

# main
if __name__ == '__main__':
        # taking input of the text line entered by the user
        line = input("Enter the line of text: ")
        # callig the repeatShift function with line as arguement
        repeatShift(line)