counter = 0
total = 0
response = input("do you want to compute you program ")

while response == "yes":
    counter = counter + 1
    qty = int(input("how many quantity"))
    priceitem = float(input("price of the item"))
    extprice = qty * priceitem
    if extprice > 10000.00:
        extprice = qty * priceitem
        discountamount = 0.10
        print("extended price of an item $", extprice)
    else:
        extprice = qty * priceitem
        discountamount = 0.25
        print("extended price of an item $", extprice)
    total = extprice - discountamount
    print(extprice + " has pay of $", discountamount)
    response = input("do you want to compute you program ")
discountamount = total / counter
print("Sum of discount amount Pay is $",discountamount)
print("Number of quantity ", counter)
